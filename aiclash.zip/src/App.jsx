import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import { useAiClash } from '@/hooks/useAiClash';
import Sidebar from '@/components/ai-clash/Sidebar';
import ConversationWindow from '@/components/ai-clash/ConversationWindow';
import ConfigurationPanel from '@/components/ai-clash/ConfigurationPanel';
import { Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';

function App() {
  const { toast } = useToast();
  const clashState = useAiClash(toast);
  const { conversationHistory, isConfiguring } = clashState;
  const [isSidebarOpen, setSidebarOpen] = useState(true);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setSidebarOpen(false);
      } else {
        setSidebarOpen(true);
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <>
      <Helmet>
        <title>AI Clash - Autonomous AI Debates</title>
        <meta name="description" content="An advanced sandbox to pit two AI models against each other in an autonomous, turn-by-turn debate. Inspired by leading AI chat interfaces." />
        <link rel="icon" href="https://storage.googleapis.com/hostinger-horizons-assets-prod/55984d85-e28f-4abb-a7dd-bb861483cc41/f0890d057d9aeb8b038aea1e7427bd4d.png" type="image/png" />
      </Helmet>
      
      <div className="flex h-screen w-full bg-[#171717] text-gray-200 font-sans">
        <Sidebar {...clashState} isSidebarOpen={isSidebarOpen} setSidebarOpen={setSidebarOpen} />
        <main className="flex flex-1 flex-col transition-all duration-300">
          <div className="flex-1 flex flex-col relative">
            {!isSidebarOpen && (
               <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-4 left-4 z-20 text-gray-400 hover:text-white md:hidden"
                  onClick={() => setSidebarOpen(true)}
                >
                  <Menu className="h-6 w-6" />
                </Button>
            )}
            {isConfiguring || conversationHistory.length === 0 ? (
              <ConfigurationPanel {...clashState} />
            ) : (
              <ConversationWindow {...clashState} toast={toast} />
            )}
          </div>
        </main>
        <Toaster />
      </div>
    </>
  );
}

export default App;