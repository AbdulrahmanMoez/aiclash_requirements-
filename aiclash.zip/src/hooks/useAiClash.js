import { useState, useEffect, useCallback } from 'react';

const providersData = [
  { value: 'openai', label: 'OpenAI' },
  { value: 'gemini', label: 'Google Gemini' },
  { value: 'anthropic', label: 'Anthropic Claude' },
  { value: 'cohere', label: 'Cohere' }
];

const modelsData = {
  openai: ['gpt-4', 'gpt-3.5-turbo', 'gpt-4-turbo'],
  gemini: ['gemini-pro', 'gemini-pro-vision'],
  anthropic: ['claude-3-opus', 'claude-3-sonnet', 'claude-3-haiku'],
  cohere: ['command', 'command-light', 'command-nightly']
};

const initialConfig = {
  modelA: {
    provider: 'openai',
    model: 'gpt-3.5-turbo',
    apiKey: ''
  },
  modelB: {
    provider: 'gemini',
    model: 'gemini-pro',
    apiKey: ''
  },
  systemPrompt: 'You are an AI assistant engaged in a debate. Present your arguments clearly, concisely, and respectfully. Your goal is to explore the topic, not to win.',
  initialPrompt: 'Debate the pros and cons of decentralized finance.',
  maxTurns: 10,
  startingModel: 'A'
};

export const useAiClash = (toast) => {
  const [isRunning, setIsRunning] = useState(false);
  const [isConfiguring, setIsConfiguring] = useState(true);
  const [conversationHistory, setConversationHistory] = useState([]);
  const [currentTurn, setCurrentTurn] = useState(0);
  const [nextModelToTalk, setNextModelToTalk] = useState('A');
  const [savedConversations, setSavedConversations] = useState([]);
  const [currentStream, setCurrentStream] = useState({ model: null, content: "" });


  const [config, setConfig] = useState(initialConfig);
  
  useEffect(() => {
    const saved = localStorage.getItem('aiClashConversations');
    if (saved) {
      setSavedConversations(JSON.parse(saved));
    }
  }, []);
  
  const callApiAndStream = useCallback(async (modelKey, history, onChunk) => {
      const modelConfig = config[modelKey];
      if (!modelConfig.apiKey) {
          throw new Error(`API key not provided for Model ${modelKey.charAt(modelKey.length - 1).toUpperCase()}`);
      }

      const responses = [
          "I understand your perspective, but I believe there's another way to look at this issue, particularly regarding scalability and user adoption challenges.",
          "That's an interesting point. However, the data suggests otherwise when we consider the long-term economic implications and regulatory hurdles.",
          "While I respect your viewpoint, I must disagree based on evidence from recent case studies that highlight security vulnerabilities.",
          "You raise valid concerns, but let me present a counterargument focusing on the potential for financial inclusion and transparency.",
          "I see the merit in your argument, yet I think we should consider the environmental impact of current consensus mechanisms."
      ];
      const fullResponse = responses[Math.floor(Math.random() * responses.length)];

      // Simulate streaming
      const words = fullResponse.split(" ");
      for (let i = 0; i < words.length; i++) {
          await new Promise(resolve => setTimeout(resolve, 50 + Math.random() * 50));
          onChunk(words.slice(0, i + 1).join(" "));
      }
      return fullResponse;
  }, [config]);


  const runConversationLoop = useCallback(async (history, currentModel, turn) => {
    if (turn >= config.maxTurns || !isRunning) {
      if(isRunning) {
         setIsRunning(false);
         if (turn >= config.maxTurns) {
            toast({
              title: "🏁 Conversation Complete!",
              description: `The AI clash has ended after ${config.maxTurns} turns.`
            });
         }
      }
      return;
    }

    try {
      setCurrentStream({ model: currentModel, content: "..." });

      const finalResponse = await callApiAndStream(`model${currentModel}`, history, (chunk) => {
        if (!isRunning) return;
        setCurrentStream({ model: currentModel, content: chunk });
      });

      if (!isRunning) {
        setCurrentStream({ model: null, content: "" });
        return;
      }
      
      const newMessage = {
        role: 'assistant',
        content: finalResponse,
        model: currentModel,
        turn: turn + 1
      };

      const updatedHistory = [...history, newMessage];
      setConversationHistory(updatedHistory);
      setCurrentTurn(turn + 1);
      setCurrentStream({ model: null, content: "" });

      const nextModel = currentModel === 'A' ? 'B' : 'A';
      setNextModelToTalk(nextModel);
      
      setTimeout(() => {
        runConversationLoop(updatedHistory, nextModel, turn + 1);
      }, 1000);

    } catch (error) {
      setIsRunning(false);
      setCurrentStream({ model: null, content: "" });
      toast({
        title: "An Error Occurred",
        description: error.message,
        variant: "destructive"
      });
    }
  }, [isRunning, config, toast, callApiAndStream]);

  const startConversation = async () => {
    if (!config.initialPrompt.trim()) {
      toast({ title: "Missing Initial Prompt", description: "Please provide an initial prompt.", variant: "destructive" });
      return;
    }
    if (!config.modelA.apiKey || !config.modelB.apiKey) {
      toast({ title: "Missing API Keys", description: "Please provide API keys for both models.", variant: "destructive" });
      return;
    }
    
    // This refined first prompt gives context to both models.
    const userPromptForModelA = `(As Model A) You are debating against Model B. Here is the topic: ${config.initialPrompt}`;
    const userPromptForModelB = `(As Model B) You are debating against Model A. Here is the topic: ${config.initialPrompt}`;
    
    const initialHistory = [
      { role: 'system', content: config.systemPrompt },
      { role: 'user', content: config.startingModel === 'A' ? userPromptForModelA : userPromptForModelB, displayContent: config.initialPrompt }
    ];
    
    setConversationHistory(initialHistory);
    setCurrentTurn(0);
    setNextModelToTalk(config.startingModel);
    setIsConfiguring(false);
    setIsRunning(true);
    
    toast({ title: "🚀 AI Clash Started!", description: "The battle of minds begins now!" });
    runConversationLoop(initialHistory, config.startingModel, 0);
  };

  const stopConversation = () => {
    setIsRunning(false);
    toast({ title: "⏹️ Conversation Stopped", description: "The AI clash has been manually halted." });
  };

  const startNewConversation = () => {
    setIsRunning(false);
    setIsConfiguring(true);
    setConversationHistory([]);
    setCurrentTurn(0);
    setConfig(prev => ({...initialConfig, modelA: prev.modelA, modelB: prev.modelB}));
  };

  const saveConversation = () => {
    if (conversationHistory.length < 2) {
      toast({ title: "Cannot Save", description: "There is no conversation to save.", variant: "destructive" });
      return;
    }
    const newSave = {
      id: Date.now(),
      title: conversationHistory.find(m => m.role === 'user')?.displayContent.substring(0, 40) + '...' || 'Untitled Clash',
      history: conversationHistory,
      config: config,
      timestamp: new Date().toISOString()
    };
    const updatedSaves = [...savedConversations, newSave];
    setSavedConversations(updatedSaves);
    localStorage.setItem('aiClashConversations', JSON.stringify(updatedSaves));
    toast({ title: "Conversation Saved!", description: "Your clash has been saved to history." });
  };

  const loadConversation = (id) => {
    const convoToLoad = savedConversations.find(c => c.id === id);
    if (convoToLoad) {
      setConversationHistory(convoToLoad.history);
      setConfig(convoToLoad.config);
      setCurrentTurn(convoToLoad.history.filter(m => m.role === 'assistant').length);
      setIsConfiguring(false);
      setIsRunning(false);
      toast({ title: "Conversation Loaded", description: `Loaded "${convoToLoad.title}".` });
    }
  };

  const deleteConversation = (id) => {
    const updatedSaves = savedConversations.filter(c => c.id !== id);
    setSavedConversations(updatedSaves);
    localStorage.setItem('aiClashConversations', JSON.stringify(updatedSaves));
    toast({ title: "Conversation Deleted", variant: "destructive" });
  };

  const exportConversation = (format) => {
    if (conversationHistory.length < 2) {
      toast({ title: "Cannot Export", description: "There is no conversation to export.", variant: "destructive" });
      return;
    }

    let data, mimeType, fileExtension;
    const filename = `AI-Clash-${new Date().toISOString()}`;

    const historyForExport = conversationHistory.map(msg => ({...msg, content: msg.displayContent || msg.content}));

    if (format === 'json') {
      data = JSON.stringify({ config, history: historyForExport }, null, 2);
      mimeType = 'application/json';
      fileExtension = 'json';
    } else if (format === 'csv') {
      const headers = "Turn,Model,Role,Content";
      const rows = historyForExport.map(msg => {
        const turn = msg.turn || (msg.role === 'system' ? 'N/A' : '0');
        const model = msg.model || 'N/A';
        const role = msg.role;
        const content = `"${(msg.content || '').replace(/"/g, '""')}"`;
        return [turn, model, role, content].join(',');
      });
      data = `${headers}\n${rows.join('\n')}`;
      mimeType = 'text/csv';
      fileExtension = 'csv';
    }

    const blob = new Blob([data], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filename}.${fileExtension}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({ title: "Export Successful", description: `Conversation downloaded as ${fileExtension.toUpperCase()}.` });
  };

  return {
    isRunning,
    isConfiguring,
    conversationHistory,
    currentTurn,
    nextModelToTalk,
    config,
    setConfig,
    startConversation,
    stopConversation,
    startNewConversation,
    providers: providersData,
    models: modelsData,
    savedConversations,
    saveConversation,
    loadConversation,
    deleteConversation,
    exportConversation,
    currentStream
  };
};