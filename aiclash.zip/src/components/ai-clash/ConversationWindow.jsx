import React, { useRef, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import { MessageSquare, Share2 } from 'lucide-react';
import SystemMessage from '@/components/ai-clash/SystemMessage';
import MessageBubble from '@/components/ai-clash/MessageBubble';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const ConversationWindow = ({
  conversationHistory,
  config,
  currentTurn,
  isRunning,
  nextModelToTalk,
  toast,
  exportConversation,
}) => {
  const conversationRef = useRef(null);

  useEffect(() => {
    if (conversationRef.current) {
      conversationRef.current.scrollTo({
        top: conversationRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, [conversationHistory]);

  return (
    <div className="relative flex-1 flex flex-col bg-[#1C1C1C]">
      <header className="flex items-center justify-between p-4 border-b border-gray-700/50">
        <div className="flex items-center gap-3 truncate">
          <MessageSquare className="w-5 h-5 sm:w-6 sm:h-6 text-purple-400 flex-shrink-0" />
          <h2 className="text-lg sm:text-xl font-bold text-white truncate">Conversation Arena</h2>
        </div>
        <div className="flex items-center gap-2 sm:gap-4">
          <span className="text-gray-400 font-mono text-xs sm:text-sm">Turn: {currentTurn}/{config.maxTurns}</span>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="w-8 h-8 sm:w-9 sm:h-9">
                <Share2 className="h-4 w-4 sm:h-5 sm:w-5 text-gray-400" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-gray-900 border-gray-700 text-white">
              <DropdownMenuItem onClick={() => exportConversation('json')} className="focus:bg-gray-800">Download as JSON</DropdownMenuItem>
              <DropdownMenuItem onClick={() => exportConversation('csv')} className="focus:bg-gray-800">Download as CSV</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>
      <div
        ref={conversationRef}
        className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-gray-800/50"
      >
        <AnimatePresence>
          {conversationHistory.map((message, index) => {
            if (message.role === 'system' || message.role === 'user') {
              return <SystemMessage key={`${message.role}-${index}`} message={message} />;
            }

            return (
              <MessageBubble
                key={`${message.model}-${message.turn}-${index}`}
                message={message}
                config={config}
                toast={toast}
              />
            );
          })}
        </AnimatePresence>
      </div>
      {isRunning && (
        <div className="p-4 bg-black/20 backdrop-blur-sm border-t border-gray-700/50">
            <div className="flex items-center justify-center gap-3">
              <div className={`w-3 h-3 rounded-full animate-pulse ${nextModelToTalk === 'A' ? 'bg-cyan-400' : 'bg-pink-400'}`}></div>
              <span className={`font-semibold text-md sm:text-lg ${nextModelToTalk === 'A' ? 'text-cyan-400' : 'text-pink-400'}`}>
                {nextModelToTalk === 'A' ? 'Model A' : 'Model B'} is thinking...
              </span>
            </div>
        </div>
      )}
    </div>
  );
};

export default React.memo(ConversationWindow);