
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Save, FolderOpen, Download } from 'lucide-react';

const HistoryManager = ({ saveConversation, loadConversation, exportConversation }) => {
  return (
    <Card className="bg-gray-900/50 border-gray-700/50 backdrop-blur-xl shadow-lg shadow-purple-500/10">
      <CardHeader>
        <CardTitle className="text-xl font-bold text-white">History</CardTitle>
        <CardDescription className="text-gray-400">
          Manage your conversation sessions.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <Button onClick={saveConversation} className="w-full justify-start bg-gray-800 hover:bg-gray-700">
          <Save className="mr-2 h-4 w-4" /> Save Current Conversation
        </Button>
        <Button onClick={loadConversation} className="w-full justify-start bg-gray-800 hover:bg-gray-700">
          <FolderOpen className="mr-2 h-4 w-4" /> Load Conversation
        </Button>
        <Button onClick={exportConversation} className="w-full justify-start bg-gray-800 hover:bg-gray-700">
          <Download className="mr-2 h-4 w-4" /> Export as Markdown
        </Button>
      </CardContent>
    </Card>
  );
};

export default React.memo(HistoryManager);
