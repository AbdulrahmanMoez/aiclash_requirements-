
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Eye, EyeOff } from 'lucide-react';

const ModelConfig = ({ modelId, icon, title, color, config, setConfig, providers, models }) => {
  const modelKey = `model${modelId}`;
  const [showApiKey, setShowApiKey] = useState(false);
  
  const handleProviderChange = (value) => {
    setConfig(prev => ({
      ...prev,
      [modelKey]: { ...prev[modelKey], provider: value, model: models[value][0] }
    }));
  };
  
  const handleModelChange = (value) => {
    setConfig(prev => ({
      ...prev,
      [modelKey]: { ...prev[modelKey], model: value }
    }));
  };
  
  const handleApiKeyChange = (e) => {
    setConfig(prev => ({
      ...prev,
      [modelKey]: { ...prev[modelKey], apiKey: e.target.value }
    }));
  };

  return (
    <Card className={`bg-gray-800/30 border border-${color}-500/30 shadow-inner shadow-${color}-500/10`}>
      <CardHeader className="p-4">
        <CardTitle className="flex items-center gap-2 text-base font-semibold">
          {icon}
          <span className={`text-${color}-300`}>{title}</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-0 space-y-4">
        <div className="space-y-2">
          <Label className="text-sm text-gray-300">Provider</Label>
          <Select value={config.provider} onValueChange={handleProviderChange}>
            <SelectTrigger className={`bg-gray-900/70 border-${color}-500/40 text-white focus:ring-${color}-500`}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent className={`bg-gray-900 border-${color}-500/50 text-white`}>
              {providers.map(provider => (
                <SelectItem key={provider.value} value={provider.value} className={`focus:bg-${color}-600/30`}>
                  {provider.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label className="text-sm text-gray-300">Model</Label>
          <Select value={config.model} onValueChange={handleModelChange}>
            <SelectTrigger className={`bg-gray-900/70 border-${color}-500/40 text-white focus:ring-${color}-500`}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent className={`bg-gray-900 border-${color}-500/50 text-white`}>
              {models[config.provider]?.map(model => (
                <SelectItem key={model} value={model} className={`focus:bg-${color}-600/30`}>
                  {model}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label className="text-sm text-gray-300">API Key</Label>
          <div className="relative">
            <Input
              type={showApiKey ? 'text' : 'password'}
              placeholder="Enter API key"
              value={config.apiKey}
              onChange={handleApiKeyChange}
              className={`bg-gray-900/70 border-${color}-500/40 text-white placeholder-gray-500 focus:ring-${color}-500 pr-10`}
            />
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="absolute inset-y-0 right-0 h-full w-10 text-gray-400 hover:text-white"
              onClick={() => setShowApiKey(!showApiKey)}
            >
              {showApiKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default React.memo(ModelConfig);
