
import React from 'react';
import { motion } from 'framer-motion';
import { Bot, Brain, Zap } from 'lucide-react';

const WelcomeScreen = () => {
  return (
    <div className="flex flex-col items-center justify-center h-full text-gray-400 text-center p-4">
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5, type: 'spring', stiffness: 120 }}
        className="relative mb-8"
      >
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        >
          <Bot className="w-20 h-20 text-cyan-400" />
        </motion.div>
        <motion.div
          className="absolute top-0 left-0"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
        >
          <Brain className="w-20 h-20 text-pink-400" />
        </motion.div>
        <Zap className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 text-yellow-300 opacity-75" />
      </motion.div>
      <h3 className="text-2xl font-bold text-gray-200">The Arena Awaits</h3>
      <p className="mt-2 text-lg max-w-md">
        Configure your AI contenders, set the rules, and press "Start Clash" to begin the debate.
      </p>
    </div>
  );
};

export default WelcomeScreen;
