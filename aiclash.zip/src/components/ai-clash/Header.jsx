
import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Sparkles } from 'lucide-react';

const Header = () => {
  return (
    <motion.header
      initial={{ opacity: 0, y: -30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="text-center"
    >
      <div className="flex items-center justify-center gap-3 mb-2">
        <div className="relative">
          <Zap className="w-14 h-14 text-yellow-300" />
          <motion.div
            animate={{ rotate: 360, scale: [1, 1.2, 1] }}
            transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
            className="absolute top-0 right-0"
          >
            <Sparkles className="w-6 h-6 text-pink-400" />
          </motion.div>
        </div>
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold bg-gradient-to-r from-blue-400 via-cyan-300 to-pink-400 bg-clip-text text-transparent tracking-tight">
          AI Clash
        </h1>
      </div>
      <p className="text-lg sm:text-xl text-gray-300 max-w-3xl mx-auto">
        A professional sandbox to pit two AI models against each other in an autonomous, turn-by-turn debate.
      </p>
    </motion.header>
  );
};

export default React.memo(Header);
