import React from 'react';
import { Button } from '@/components/ui/button';
import { Plus, MessageSquare, Trash2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const Sidebar = ({ savedConversations, loadConversation, deleteConversation, startNewConversation, isSidebarOpen, setSidebarOpen }) => {
  const sidebarVariants = {
    open: {
      x: 0,
      width: '18rem', // w-72
      transition: { type: 'spring', stiffness: 300, damping: 30 }
    },
    closed: {
      x: '-100%',
      width: '18rem',
      transition: { type: 'spring', stiffness: 300, damping: 30 }
    }
  };

  const mobileSidebarVariants = {
    open: { x: 0 },
    closed: { x: '-100%' }
  };
  
  return (
    <>
      {/* Desktop Sidebar */}
      <motion.aside
        variants={sidebarVariants}
        initial={false}
        animate={isSidebarOpen ? "open" : "closed"}
        className="hidden md:flex flex-col bg-black/30 p-4 border-r border-gray-800 relative"
      >
        <div className="px-2 mb-4 flex items-center justify-between">
          <div className="relative group">
            <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
            <img src="https://storage.googleapis.com/hostinger-horizons-assets-prod/55984d85-e28f-4abb-a7dd-bb861483cc41/f0890d057d9aeb8b038aea1e7427bd4d.png" alt="AI Clash Logo" className="relative w-40 mx-auto" />
          </div>
        </div>
        <Button onClick={startNewConversation} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white font-semibold hover:opacity-90 transition-opacity">
          <Plus className="mr-2 h-5 w-5" /> New Clash
        </Button>
        <div className="mt-6 flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-gray-800/50">
          <h3 className="text-sm font-semibold text-gray-400 px-2 mb-2">History</h3>
          {/* History items */}
          <AnimatePresence>
            {savedConversations.length > 0 ? (
              savedConversations.map((convo) => (
                <motion.div
                  key={convo.id}
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.2 }}
                  layout
                  className="group flex items-center justify-between p-2 rounded-lg hover:bg-gray-800/50 cursor-pointer"
                  onClick={() => loadConversation(convo.id)}
                >
                  <div className="flex items-center gap-2 truncate">
                    <MessageSquare className="h-4 w-4 text-gray-500 flex-shrink-0" />
                    <span className="text-sm truncate">{convo.title}</span>
                  </div>
                  <Button variant="ghost" size="icon" className="h-7 w-7 opacity-0 group-hover:opacity-100 text-gray-500 hover:text-red-500 flex-shrink-0" onClick={(e) => { e.stopPropagation(); deleteConversation(convo.id); }}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </motion.div>
              ))
            ) : (
              <div className="text-center text-xs text-gray-500 p-4">No saved clashes yet.</div>
            )}
          </AnimatePresence>
        </div>
      </motion.aside>

      {/* Mobile Sidebar */}
      <AnimatePresence>
        {isSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 bg-black/60 z-30 md:hidden"
              onClick={() => setSidebarOpen(false)}
            />
            <motion.aside
              variants={mobileSidebarVariants}
              initial="closed"
              animate="open"
              exit="closed"
              transition={{ type: 'spring', stiffness: 400, damping: 40 }}
              className="fixed top-0 left-0 h-full w-72 bg-[#1C1C1C] p-4 flex flex-col border-r border-gray-800 z-40 md:hidden"
            >
              <div className="px-2 mb-4 flex items-center justify-between">
                <div className="relative group">
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
                  <img src="https://storage.googleapis.com/hostinger-horizons-assets-prod/55984d85-e28f-4abb-a7dd-bb861483cc41/f0890d057d9aeb8b038aea1e7427bd4d.png" alt="AI Clash Logo" className="relative w-40 mx-auto" />
                </div>
                <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(false)}>
                  <X className="h-6 w-6" />
                </Button>
              </div>
              <Button onClick={() => { startNewConversation(); setSidebarOpen(false); }} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white font-semibold hover:opacity-90 transition-opacity">
                <Plus className="mr-2 h-5 w-5" /> New Clash
              </Button>
              <div className="mt-6 flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-gray-800/50">
                <h3 className="text-sm font-semibold text-gray-400 px-2 mb-2">History</h3>
                {/* History items */}
                {savedConversations.length > 0 ? (
                  savedConversations.map((convo) => (
                    <div
                      key={convo.id}
                      className="group flex items-center justify-between p-2 rounded-lg hover:bg-gray-800/50 cursor-pointer"
                      onClick={() => { loadConversation(convo.id); setSidebarOpen(false); }}
                    >
                      <div className="flex items-center gap-2 truncate">
                        <MessageSquare className="h-4 w-4 text-gray-500 flex-shrink-0" />
                        <span className="text-sm truncate">{convo.title}</span>
                      </div>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-gray-500 hover:text-red-500 flex-shrink-0" onClick={(e) => { e.stopPropagation(); deleteConversation(convo.id); }}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))
                ) : (
                  <div className="text-center text-xs text-gray-500 p-4">No saved clashes yet.</div>
                )}
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default React.memo(Sidebar);