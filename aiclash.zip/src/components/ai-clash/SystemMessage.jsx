import React from 'react';
import { motion } from 'framer-motion';
import { Layers, User } from 'lucide-react';

const SystemMessage = ({ message }) => {
  const isSystem = message.role === 'system';
  
  const variants = {
    hidden: { opacity: 0, y: 10 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.3 } }
  };

  return (
    <motion.div
      variants={variants}
      initial="hidden"
      animate="visible"
      className="p-4 rounded-lg bg-black/20 border border-gray-800 max-w-3xl mx-auto"
    >
      <div className="flex items-center gap-3 mb-2">
        {isSystem ? (
          <Layers className="w-5 h-5 text-purple-400" />
        ) : (
          <User className="w-5 h-5 text-green-400" />
        )}
        <span className="font-semibold text-sm tracking-wide uppercase" style={{color: isSystem ? '#a78bfa' : '#4ade80'}}>
          {isSystem ? 'System Prompt' : 'Initial Prompt'}
        </span>
      </div>
      <p className="text-gray-300 leading-relaxed text-base">{message.displayContent || message.content}</p>
    </motion.div>
  );
};

export default React.memo(SystemMessage);