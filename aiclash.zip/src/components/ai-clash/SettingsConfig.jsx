import React from 'react';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const SettingsConfig = ({ config, setConfig }) => {
  const handleInputChange = (key, value) => {
    setConfig(prev => ({ ...prev, [key]: value }));
  };
  
  const handleNumericInputChange = (key, value) => {
    setConfig(prev => ({ ...prev, [key]: parseInt(value) || 1 }));
  };
  
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label className="text-gray-300">System Prompt</Label>
        <Textarea
          placeholder="Define the overarching context and rules for both models..."
          value={config.systemPrompt}
          onChange={(e) => handleInputChange('systemPrompt', e.target.value)}
          className="bg-gray-900/70 border-gray-600 min-h-[120px] text-white placeholder-gray-500 focus:ring-blue-500"
        />
      </div>
      
      <div className="space-y-2">
        <Label className="text-gray-300">Initial Prompt</Label>
        <Textarea
          placeholder="The opening statement or question to kick off the debate."
          value={config.initialPrompt}
          onChange={(e) => handleInputChange('initialPrompt', e.target.value)}
          className="bg-gray-900/70 border-gray-600 min-h-[80px] text-white placeholder-gray-500 focus:ring-blue-500"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label className="text-gray-300">Max Turns</Label>
          <Input
            type="number"
            min="1"
            max="50"
            value={config.maxTurns}
            onChange={(e) => handleNumericInputChange('maxTurns', e.target.value)}
            className="bg-gray-900/70 border-gray-600 text-white focus:ring-blue-500"
          />
        </div>
        
        <div className="space-y-2">
          <Label className="text-gray-300">Starting Model</Label>
          <Select
            value={config.startingModel}
            onValueChange={(value) => handleInputChange('startingModel', value)}
          >
            <SelectTrigger className="bg-gray-900/70 border-gray-600 text-white focus:ring-blue-500">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-gray-900 border-gray-600 text-white">
              <SelectItem value="A" className="focus:bg-cyan-600/30">Model A</SelectItem>
              <SelectItem value="B" className="focus:bg-pink-600/30">Model B</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
};

export default SettingsConfig;