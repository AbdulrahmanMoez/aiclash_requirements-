
import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Bot, Brain, Clipboard } from 'lucide-react';
import { Button } from '@/components/ui/button';

const MessageBubble = ({ message, config, toast }) => {
  const isModelA = message.model === 'A';
  const modelConfig = isModelA ? config.modelA : config.modelB;
  
  const bubbleVariants = {
    hidden: { opacity: 0, y: 20, scale: 0.95 },
    visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.4, ease: "easeOut" } }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    toast({
      title: "Copied to clipboard!",
      description: `Message from Model ${message.model} has been copied.`,
    });
  };

  return (
    <motion.div
      variants={bubbleVariants}
      initial="hidden"
      animate="visible"
      className={`group flex items-start gap-4 w-full max-w-3xl mx-auto`}
    >
      <div className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center ${isModelA ? 'bg-cyan-900/50 text-cyan-400' : 'bg-pink-900/50 text-pink-400'}`}>
        {isModelA ? <Bot className="w-6 h-6" /> : <Brain className="w-6 h-6" />}
      </div>
      <div className={`w-full text-left`}>
        <div className={`font-bold text-lg mb-2 flex items-center gap-2`}>
          <span className={isModelA ? 'text-cyan-300' : 'text-pink-300'}>
            Model {message.model}
          </span>
          <span className="text-gray-500 font-mono text-xs">({modelConfig.model})</span>
        </div>
        <div className="text-gray-200 leading-relaxed text-base space-y-4" dangerouslySetInnerHTML={{ __html: message.content.replace(/\n/g, '<br />') }} />
        <div className="flex items-center gap-2 mt-3">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-gray-500 hover:text-white hover:bg-gray-700/50"
              onClick={handleCopy}
              aria-label="Copy message"
            >
              <Clipboard className="w-4 h-4" />
            </Button>
        </div>
      </div>
    </motion.div>
  );
};

export default React.memo(MessageBubble);
