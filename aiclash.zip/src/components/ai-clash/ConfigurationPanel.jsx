import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Play, Bot, Brain, Settings } from 'lucide-react';
import ModelConfig from '@/components/ai-clash/ModelConfig';
import SettingsConfig from '@/components/ai-clash/SettingsConfig';

const ConfigurationPanel = ({
  config,
  setConfig,
  startConversation,
  models,
  providers,
}) => {
  return (
    <motion.div
      key="config-panel"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.3 }}
      className="flex-1 flex flex-col items-center justify-center p-4 md:p-8 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-gray-800/50"
    >
      <div className="w-full max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-4xl sm:text-5xl font-bold text-white">Setup Your AI Clash</h1>
          <p className="text-gray-400 mt-2 text-md sm:text-lg">Configure the contenders and define the rules for the debate.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mb-8">
          <ModelConfig
            modelId="A"
            icon={<Bot className="w-6 h-6 text-cyan-400" />}
            title="Model A (Challenger)"
            color="cyan"
            config={config.modelA}
            setConfig={setConfig}
            providers={providers}
            models={models}
          />
          <ModelConfig
            modelId="B"
            icon={<Brain className="w-6 h-6 text-pink-400" />}
            title="Model B (Incumbent)"
            color="pink"
            config={config.modelB}
            setConfig={setConfig}
            providers={providers}
            models={models}
          />
        </div>

        <div className="bg-gray-900/50 border border-gray-700/50 rounded-xl p-4 sm:p-6 mb-8">
            <div className="flex items-center gap-3 mb-4">
                <Settings className="w-6 h-6 text-purple-400" />
                <h2 className="text-xl sm:text-2xl font-bold text-white">Rules of Engagement</h2>
            </div>
            <SettingsConfig config={config} setConfig={setConfig} />
        </div>

        <div className="text-center">
          <Button
            onClick={startConversation}
            size="lg"
            className="bg-gradient-to-r from-purple-600 to-blue-600 text-white font-bold text-md sm:text-lg py-4 px-6 sm:py-7 sm:px-10 rounded-full hover:shadow-lg hover:shadow-blue-500/30 transition-all duration-300 transform hover:scale-105"
          >
            <Play className="w-5 h-5 sm:w-6 sm:h-6 mr-2 sm:mr-3" />
            Start The Clash
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

export default React.memo(ConfigurationPanel);